package Team2.youngcha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoungchaApplicationTests {

	@Test
	void contextLoads() {
	}

}
